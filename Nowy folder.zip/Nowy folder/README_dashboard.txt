dashboard.py created. Run it in your project root (where 'mydatabase.duckdb' and 'processed' are located):

python /mnt/data/dashboard.py

It will write outputs into processed/ (map.html, top_distances.png, dashboard.html). Ensure required packages are installed: pandas folium matplotlib
